<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lead_status_type extends Model
{
    use HasFactory;

    protected $table = 'lead_status_type';
}
