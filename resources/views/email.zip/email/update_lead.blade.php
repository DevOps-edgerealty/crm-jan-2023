<h2>Customer Relationship Management &#40;CRM&#41; Notification</h2><br>


<table class="table table-striped" style="font-size: 16px; padding: 10px;">

    <tbody>
      <tr>

        <td>You Have 1 Updated Lead. Please Check CRM.</td>
        <td><a href="https://crm.edgerealty.ae/leads/">Click Here To See Your Lead</a></td>

      </tr>



    </tbody>
</table>


<br>

<p>Do not attempt to reply to this email as this is a computer generated email from the Edge Realty Real Estate Customer Relationship System. <br>For more information regarding this email, please contact the administrator at <a href="mailto: web@edgerealty.ae">web@edgerealty.ae</a> </p>
<h2>Thank You</h2>

<div>
  <img src="{{URL::asset('assets/images/logo-black.png')}}" height="279px" width="106" alt="Edge-Realty-Official-Logo"/>
</div>